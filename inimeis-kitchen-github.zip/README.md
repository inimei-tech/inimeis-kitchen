# 🍳 Inimei's Kitchen

**Dein persönliches digitales Kochbuch — mit eingebautem Einkaufsplaner, Wochenbudget und Preisgedächtnis.**

> Kostenlos. Kein Abo. Keine Cloud. Alle Daten bleiben auf deinem Gerät.

🌐 **Live:** [inimeiskitchen.com](https://inimeiskitchen.com)

---

## ✨ Features

| Feature | Beschreibung |
|---|---|
| 🛒 **Einkaufsliste** | 230+ Artikel mit Preisgedächtnis aus echten Kassenbons |
| 📖 **Digitales Kochbuch** | 43+ Rezepte, eigene hinzufügbar |
| 📅 **Wochenplaner** | Mahlzeiten planen, alle Zutaten auf einmal auf die Liste |
| 💰 **Budget-Optimierung** | Wochenplan automatisch aus deinem Budget generieren |
| 📷 **Belegscanner** | Bon fotografieren → KI liest Preise → Datenbank aktualisiert |
| 🍽 **Schnell kochen** | Rezept wählen → Zutaten sofort auf die Einkaufsliste |
| 📱 **PWA** | Als App auf dem iPhone speichern — kein App Store nötig |

---

## 🚀 Installation

### Option 1 — Direkt nutzen (empfohlen)
👉 [inimeiskitchen.com](https://inimeiskitchen.com) öffnen → Safari → Teilen → **Zum Home-Bildschirm**

### Option 2 — Selbst hosten
```bash
git clone https://github.com/inimei-tech/inimeis-kitchen.git
cd inimeis-kitchen
# Einfach index.html in einem Webserver-Ordner ablegen
# oder lokal öffnen: open index.html
```

### Option 3 — Fork & Anpassen
Fork dieses Repo, passe Rezepte und Preise an deine Region an!

---

## 📷 Belegscanner einrichten (optional)

Der Belegscanner nutzt die [Anthropic Claude API](https://console.anthropic.com).

1. Kostenlosen API Key holen: [console.anthropic.com](https://console.anthropic.com)
2. In der App: Einstellungen → API Key eintragen
3. Der Key wird **nur lokal** auf deinem Gerät gespeichert — nie auf einem Server

> **Hinweis für Entwickler:** Trage den Key niemals direkt in den Code ein und checke ihn nie in Git ein. Nutze stattdessen `.env` Dateien oder den localStorage-Mechanismus der App.

---

## 🛠 Technik

- **Pure HTML/CSS/JS** — kein Framework, kein Build-Prozess
- **localStorage** — alle Daten lokal, kein Server
- **PWA** — installierbar, offline-fähig
- **Anthropic Claude API** — nur für Belegscanner (optional)
- **Mobile-first** — optimiert für iPhone/Safari

---

## 🗂 Projektstruktur

```
inimeis-kitchen/
├── index.html          # Die komplette App (eine Datei!)
├── README.md           # Diese Datei
├── LICENSE             # MIT License
└── CONTRIBUTING.md     # Wie du mitmachen kannst
```

---

## 🤝 Mitmachen

Beiträge sind herzlich willkommen! Besonders:

- 🥘 **Neue Rezepte** hinzufügen
- 🏪 **Preise** aus deiner Region ergänzen
- 🌍 **Übersetzungen** (Türkisch, Englisch, etc.)
- 🐛 **Bugs** melden

Bitte lies zuerst [CONTRIBUTING.md](CONTRIBUTING.md).

---

## 💝 Unterstützen

Inimei's Kitchen ist und bleibt kostenlos.  
Wenn dir die App hilft, freue ich mich über eine kleine Spende:

☕ [Ko-fi: ko-fi.com/inimei](https://ko-fi.com/inimei)

Oder abonniere den **Inimei Newsletter** für neue Rezepte und Updates:  
📬 [inimei.de](https://inimei.de)

---

## 👩‍💻 Über die Entwicklerin

Gebaut von **Gülsen Kitzel** — Gründerin, Musikerin und Bloggerin aus der Pfalz.

> *"Herzenspoesie für mehr Menschlichkeit"*

- 🌐 [inimei.de](https://inimei.de)
- 💼 [PalzCare](https://palzcare.de) — Nachbarschaftshilfe in der Pfalz
- 📸 Instagram: [@inimei](https://instagram.com/inimei)

---

## 📄 Lizenz

MIT License — siehe [LICENSE](LICENSE)

Du darfst den Code frei nutzen, verändern und weitergeben.  
Eine Erwähnung freut mich natürlich! 😊
